<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
use Illuminate\Database\Eloquent\Model as Eloquent;
class Arsip_model extends Eloquent{
	protected $table = 'arsip';
    public $timestamps = false;
}

/* End of file Users_model.php */
